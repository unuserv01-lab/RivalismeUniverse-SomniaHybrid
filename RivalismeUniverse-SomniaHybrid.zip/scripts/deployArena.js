// scripts/deployArena.js
const hre = require("hardhat");

async function main() {
  const SomniaArena = await hre.ethers.getContractFactory("SomniaArena");
  // replace with persona contract address when deploying
  const arena = await SomniaArena.deploy("0xREPLACE_PERSONA_ADDRESS");
  await arena.deployed();
  console.log("SomniaArena deployed to:", arena.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
