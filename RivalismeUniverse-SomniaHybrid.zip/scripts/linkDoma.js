// scripts/linkDoma.js
const hre = require("hardhat");

async function main() {
  // Example of linking domain after deploying DomaIdentityLink
  const DomaLink = await hre.ethers.getContractFactory("DomaIdentityLink");
  const link = await DomaLink.deploy();
  await link.deployed();
  console.log("DomaIdentityLink deployed to:", link.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
