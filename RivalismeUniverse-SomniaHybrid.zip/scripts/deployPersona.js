// scripts/deployPersona.js
const hre = require("hardhat");

async function main() {
  const SomniaPersona = await hre.ethers.getContractFactory("SomniaPersonaNFT");
  const persona = await SomniaPersona.deploy();
  await persona.deployed();
  console.log("SomniaPersonaNFT deployed to:", persona.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
