// app.js — minimal wallet connect + mint using ethers.js
let provider, signer;
const CONTRACT_ADDRESS = ""; // replace after deployment
const CONTRACT_ABI = [
  // minimal ABI for mintPersona(name, spec, uri)
  "function mintPersona(string memory name, string memory spec, string memory uri) public returns (uint256)"
];

async function connectWallet(){
  if(window.ethereum){
    try{
      await window.ethereum.request({method:'eth_requestAccounts'});
      provider = new ethers.providers.Web3Provider(window.ethereum);
      signer = provider.getSigner();
      const addr = await signer.getAddress();
      document.getElementById('walletAddress').innerText = 'Connected: ' + addr;
    }catch(e){
      alert('Connection rejected');
      console.error(e);
    }
  } else {
    alert('No injected wallet found. Install MetaMask or Somnia-compatible wallet.');
  }
}

async function mintPersona(){
  const name = document.getElementById('personaName').value || 'UnnamedPersona';
  const spec = document.getElementById('personaSpec').value || 'General';
  const uri = document.getElementById('personaURI').value || '';
  if(!signer){
    alert('Please connect wallet first');
    return;
  }
  if(!CONTRACT_ADDRESS){
    alert('Contract address not set in app.js — deploy contract and paste address');
    return;
  }
  const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
  try{
    const tx = await contract.mintPersona(name, spec, uri);
    document.getElementById('status').innerText = 'Minting... ' + tx.hash;
    await tx.wait();
    document.getElementById('status').innerText = 'Mint success! Tx: ' + tx.hash;
  }catch(e){
    console.error(e);
    document.getElementById('status').innerText = 'Error: ' + (e.message || e);
  }
}

document.getElementById('connectWallet').onclick = connectWallet;
document.getElementById('mintPersona').onclick = mintPersona;
