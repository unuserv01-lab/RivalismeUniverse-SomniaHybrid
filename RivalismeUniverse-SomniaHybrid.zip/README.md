# RivalismeUniverse — Somnia Hybrid (HTML/JS demo)

This ZIP contains a minimal hybrid version of RivalismeUniverse:
- HTML/JS frontend (manual)
- Dummy Globe page (static / non-interactive)
- 3 Solidity contracts for Somnia/Doma integration
- Hardhat deploy scripts (placeholders)
- Simple instructions to deploy on Somnia testnet (fill RPC & private key)

## Quick start (laptop recommended)
1. Extract ZIP.
2. Install dependencies: `npm install`
3. Fill `.env` with SOMNIA_RPC_URL and DEPLOYER_PRIVATE_KEY.
4. Compile & deploy: `npx hardhat compile` and `npx hardhat run scripts/deployPersona.js --network somnia`
5. Copy deployed contract address into `app.js` (CONTRACT_ADDRESS).
6. Open `index.html` in browser and test connect + mint (use MetaMask configured to Somnia testnet).

## Notes
- hardhat.config.js contains placeholder network config. Keep private keys out of repo.
- This is a demo scaffold: arena contract and Doma link contract included as starting point.
